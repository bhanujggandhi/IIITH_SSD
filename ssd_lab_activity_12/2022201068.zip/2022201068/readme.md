# Lab Activity 12

**Bhanuj**
**2022201068**

---

### Q1

- Matrix will be read from the file called _reading.txt_ which should be present in the same directory.
- I have considered that walker will start from left foot and when I get first time maximum area in the grid, I assume that the whole foot is on the mat.
- If grid has 2 feet that means the change of foot is going to happen.
- I have calculated the left and right foot and difference between first left and second left foot to calculate the stride length.
- Time difference for velocity is calculated using median or 23 index of each matrix.

### Q2

- I have merged the 3 mats in reading2.txt and applied the same logic and assumed that there is always one person.
- That means at a time at max only two feet can be present.
- Question was unclear so I made this assumption.
